"""Check delivered result counts and build a portable, local-only package."""
from pathlib import Path
import json, hashlib, zipfile, sys
import pandas as pd
import numpy as np
sys.stdout.reconfigure(encoding='utf-8')
root=Path(__file__).resolve().parent
out=root/'results'
raw=pd.read_csv(out/'raw_tidy.csv',dtype={'run':str,'code':str})
g=pd.read_csv(out/'growth_fits.csv')
r=pd.read_csv(out/'reporter_fits.csv')
d=pd.read_csv(out/'dose_model_comparison.csv')
h=pd.read_csv(out/'dose_holdout_predictions.csv')
c=pd.read_csv(out/'reporter_comparison_summary.csv')
ev=json.loads((out/'archive_evidence_checks.json').read_text())
checks={
 'raw_runs':int(raw.run.nunique()),
 'measured_wells':int(raw[['run','well']].drop_duplicates().shape[0]),
 'well_time_rows':len(raw),
 'main_groups':int(raw[raw.code.notna()][['run','label','code']].drop_duplicates().shape[0]),
 'growth_fits':len(g), 'growth_fits_converged':int(g.converged.sum()),
 'reporter_fits':len(r), 'dose_fits':len(d), 'dose_fits_converged':int(d.converged.sum()),
 'omitted_dose_predictions':len(h),
 'all_reporter_errors_finite':bool(np.isfinite(r.rmse_RFU).all()),
 'all_omitted_dose_predictions_finite':bool(np.isfinite(h.predicted).all()),
 'October2_excluded_from_numeric_dose_fits':not (d.run==20261002).any(),
 'full_archive_cached_workbook_values_identical':all(x['cached_value_differences']==0 for x in ev['cached_workbook_comparisons']),
 'PNG_figures':len(list((root/'figures').glob('*.png'))),
 'PDF_figures':len(list((root/'figures').glob('*.pdf'))),
 'AB1_files_inventoried':ev['ab1_files'],
}
cc=c[(c['case']=='two_b009')&(c.m_per_h==1)&(c.loss_upper==1)]
checks['primary_GM_lower_RMSE']=int(cc.GM_lower_RMSE.sum())
checks['primary_BP_lower_RMSE']=int(cc.BP_lower_RMSE.sum())
checks['primary_ties']=int(cc.groups.sum()-cc.GM_lower_RMSE.sum()-cc.BP_lower_RMSE.sum())
assert checks['raw_runs']==5 and checks['measured_wells']==388 and checks['main_groups']==126
assert len(g)==504 and g.converged.all() and len(r)==2142
assert len(d)==228 and len(h)==1140 and d.converged.all()
assert checks['all_reporter_errors_finite'] and checks['all_omitted_dose_predictions_finite']
assert checks['full_archive_cached_workbook_values_identical']
assert checks['primary_GM_lower_RMSE']==99 and checks['primary_BP_lower_RMSE']==24 and checks['primary_ties']==3
assert checks['October2_excluded_from_numeric_dose_fits']
(out/'delivery_checks.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')

# Whitelist deliverables: never include browser state, cookies, tokens or logs.
files=[]
for p in root.iterdir():
 if p.is_file() and p.name!='package_checksums.json' and (p.suffix in ['.py','.json'] or p.name in ['README.txt','analysis_report.html','analysis_report.txt','missing_information.txt']):
  files.append(p)
for folder in ['results','figures','source']:
 files.extend(p for p in (root/folder).rglob('*') if p.is_file())
files=sorted(set(files))
hashes={str(p.relative_to(root)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(root/'package_checksums.json').write_text(json.dumps(hashes,indent=2,ensure_ascii=False),encoding='utf-8')
files=[p for p in files if p.name!='package_checksums.json']+[root/'package_checksums.json']
target=root/'Cadture_analysis_update_20261011.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:z.write(p,'Cadture_analysis_update_20261011/'+str(p.relative_to(root)))
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None
print(json.dumps(checks,indent=2))
print('Package:',target,'files:',len(files),'size MB:',round(target.stat().st_size/1e6,2))
