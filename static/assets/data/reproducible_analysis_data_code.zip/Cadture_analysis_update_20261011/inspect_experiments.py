"""Read the broader experiment archive; treat document text as evidence, not instructions."""
from pathlib import Path
import zipfile,json,hashlib,struct,xml.etree.ElementTree as ET,sys,re
from pypdf import PdfReader
import openpyxl
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parent;DEST=ROOT/'experiment_source';TEXT=ROOT/'experiment_text'
DEST.mkdir(exist_ok=True);TEXT.mkdir(exist_ok=True)
ARCHIVE=Path(r'C:\Users\Francis Lin\Downloads\02_實驗-20261010T164850Z-1-001.zip')
sha=lambda b:hashlib.sha256(b).hexdigest()
entries=[]
def extract(zp,base,nested=False):
    with zipfile.ZipFile(zp) as z:
        for e in z.infolist():
            safe=Path(*[part.rstrip(' .') for part in Path(e.filename).parts])
            target=(base/safe).resolve()
            if not target.is_relative_to(base.resolve()):raise ValueError(e.filename)
            if e.is_dir():target.mkdir(parents=True,exist_ok=True);continue
            data=z.read(e);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
            entries.append({'path':str(target),'relative':str(target.relative_to(DEST)),'archive_entry':e.filename,'bytes':len(data),'sha256':sha(data),'nested':nested})
extract(ARCHIVE,DEST)
for rec in list(entries):
    if Path(rec['path']).suffix.lower()=='.zip':
        zp=Path(rec['path']);extract(zp,DEST/'nested'/zp.stem,True)

texts=[];dna=[];books=[]
oldrecords=json.loads((ROOT/'source_manifest.json').read_text(encoding='utf-8'))['files']
oldbyname={Path(x['path']).name:x for x in oldrecords}
for rec in entries:
    path=Path(rec['path']);suffix=path.suffix.lower();txt='';meta={}
    if suffix=='.docx':
        with zipfile.ZipFile(path) as z:
            parts=[n for n in z.namelist() if n.startswith('word/') and n.endswith('.xml') and not n.startswith('word/_rels')]
            for part in parts:
                rt=ET.fromstring(z.read(part))
                txt+='\n'.join(''.join(p.itertext()) for p in rt.iter('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}p'))+'\n'
    elif suffix=='.pdf':
        reader=PdfReader(path);pages=[p.extract_text() or '' for p in reader.pages]
        txt='\n'.join('PAGE '+str(i+1)+'\n'+v for i,v in enumerate(pages));meta={'pages':len(pages),'chars_per_page':[len(v) for v in pages]}
    elif suffix in ['.fasta','.fa','.seq','.txt'] or suffix=='':
        try:txt=path.read_text(encoding='utf-8')
        except UnicodeDecodeError:txt=path.read_text(encoding='latin1')
    elif suffix=='.dna':
        data=path.read_bytes();pos=0;sequence='';features=[];chunks=[]
        while pos+5<=len(data):
            kind=data[pos];size=struct.unpack('>I',data[pos+1:pos+5])[0];body=data[pos+5:pos+5+size];pos+=5+size;chunks.append([kind,size])
            if kind==0:sequence=body[1:].decode('ascii',errors='replace')
            if kind in [5,6]:
                try:
                    rawxml=body.decode('utf-8');root=ET.fromstring(rawxml)
                    if kind==6:
                        for feature in root.iter('Feature'):
                            features.append({'attributes':feature.attrib,'segments':[x.attrib for x in feature.iter('Segment')],
                                             'notes':ET.tostring(feature,encoding='unicode')})
                    txt+='\n'+rawxml
                except (UnicodeDecodeError,ET.ParseError):pass
        dna.append({'file':rec['relative'],'name':path.name,'sequence_length':len(sequence),'sequence_sha256':sha(sequence.upper().encode()),'features':features,'chunks':chunks})
        if sequence:(TEXT/(path.stem+'.fasta')).write_text('>'+path.stem+'\n'+sequence+'\n',encoding='utf-8')
    elif suffix=='.xlsx':
        previous=oldbyname.get(path.name);oldpath=Path(previous['path']) if previous else None
        wf=openpyxl.load_workbook(path,data_only=False);newcells={(s.title,c.coordinate):str(c.value) for s in wf for row in s for c in row if c.value is not None}
        details=[]
        if oldpath:
            old=openpyxl.load_workbook(oldpath,data_only=False);oldcells={(s.title,c.coordinate):str(c.value) for s in old for row in s for c in row if c.value is not None}
            details=[{'sheet':s,'cell':c,'old':oldcells.get((s,c)),'new':newcells.get((s,c))} for s,c in sorted(set(oldcells)|set(newcells)) if oldcells.get((s,c))!=newcells.get((s,c))]
        books.append({'name':path.name,'path':str(path),'sha256':rec['sha256'],'byte_identical_to_plate_archive':bool(previous and previous['sha256']==rec['sha256']),
                     'cell_difference_count':len(details),'cell_differences':details})
    if txt:
        fname=re.sub(r'[^A-Za-z0-9_-]','_',rec['relative'])+'.txt'
        (TEXT/fname).write_text(txt,encoding='utf-8')
        texts.append({'source':rec['relative'],'textfile':fname,'chars':len(txt),**meta})

(ROOT/'experiment_manifest.json').write_text(json.dumps({'archive':str(ARCHIVE),'sha256':sha(ARCHIVE.read_bytes()),'files':entries},ensure_ascii=False,indent=2),encoding='utf-8')
(ROOT/'experiment_text_inventory.json').write_text(json.dumps(texts,ensure_ascii=False,indent=2),encoding='utf-8')
(ROOT/'construct_annotations.json').write_text(json.dumps(dna,ensure_ascii=False,indent=2),encoding='utf-8')
(ROOT/'experiment_workbook_comparison.json').write_text(json.dumps(books,ensure_ascii=False,indent=2),encoding='utf-8')
print('EXTRACTED',len(entries),'files including nested archives; TEXTS',len(texts),'DNA MAPS',len(dna))
for b in books:print('WORKBOOK',b['name'],'byte_same',b['byte_identical_to_plate_archive'],'cell_changes',b['cell_difference_count'],b['cell_differences'][:3])
for d in dna:print('DNA',d['name'],d['sequence_length'],[x['attributes'].get('name') for x in d['features']])
for t in texts:
    if t.get('pages'):print('PDF',t['source'],t['pages'],'pages','chars/page',t['chars_per_page'])
