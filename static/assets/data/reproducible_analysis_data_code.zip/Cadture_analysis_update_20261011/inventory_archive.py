"""Inventory the supplied archive without modifying source files."""
from pathlib import Path
import zipfile, hashlib, json, re, datetime, csv, sys
sys.stdout.reconfigure(encoding='utf-8')
import openpyxl

ROOT = Path(__file__).resolve().parent
ARCHIVE = Path(r'C:\Users\Francis Lin\Downloads\Plate Reader - Result-20261010T162924Z-1-001.zip')
OLD = Path(r'C:\Users\Francis Lin\Downloads\20260910pMH45-pVIS1234(student).xlsx')
EXTRACT = ROOT / 'source'
EXTRACT.mkdir(parents=True, exist_ok=True)
sha = lambda b: hashlib.sha256(b).hexdigest()
def normalize(v):
    if isinstance(v, (datetime.datetime, datetime.date, datetime.time)): return v.isoformat()
    return v
def cells(wb):
    return [[s.title, c.coordinate, normalize(c.value)] for s in wb for row in s for c in row if c.value is not None]

manifest = {'archive':str(ARCHIVE), 'archive_sha256':sha(ARCHIVE.read_bytes()), 'files':[]}
with zipfile.ZipFile(ARCHIVE) as z:
    for entry in z.infolist():
        if entry.is_dir(): continue
        target = (EXTRACT / entry.filename).resolve()
        if not target.is_relative_to(EXTRACT.resolve()): raise ValueError('Unsafe archive entry')
        target.parent.mkdir(parents=True, exist_ok=True)
        content = z.read(entry)
        target.write_bytes(content)
        manifest['files'].append({'archive_entry':entry.filename,'path':str(target),'bytes':len(content),'sha256':sha(content)})

old_wb = openpyxl.load_workbook(OLD, data_only=False)
old_cells = cells(old_wb)
old_dict = {(s,c):v for s,c,v in old_cells}
manifest['previous_source'] = {'path':str(OLD),'sha256':sha(OLD.read_bytes())}
inventory = []
for file in manifest['files']:
    path=Path(file['path'])
    if path.suffix.lower()!='.xlsx': continue
    wf=openpyxl.load_workbook(path,data_only=False)
    wv=openpyxl.load_workbook(path,data_only=True)
    f_cells=cells(wf)
    row={'name':path.name,'path':str(path),'sha256':file['sha256'],'logical_cells_sha256':sha(json.dumps(f_cells,ensure_ascii=False,sort_keys=True,default=str).encode()),'sheets':[]}
    if path.name==OLD.name:
        nd={(s,c):v for s,c,v in f_cells}
        diffs=[{'sheet':s,'cell':c,'old':old_dict.get((s,c)),'new':nd.get((s,c))} for s,c in sorted(set(old_dict)|set(nd)) if old_dict.get((s,c))!=nd.get((s,c))]
        row['comparison_to_previous']={'byte_identical':file['sha256']==manifest['previous_source']['sha256'],'cell_changes':len(diffs),'differences':diffs}
    dump=[]
    for s in wf:
        sv=wv[s.title]
        comments=[{'cell':c.coordinate,'text':c.comment.text} for rr in s for c in rr if c.comment]
        errors=[{'cell':c.coordinate,'value':str(c.value),'cached':str(sv[c.coordinate].value)} for rr in s for c in rr if c.data_type=='e' or sv[c.coordinate].data_type=='e']
        heads=[{'row':r[0].row,'well':r[0].value} for r in sv if isinstance(r[0].value,str) and re.fullmatch(r'[A-H](?:[1-9]|1[0-2])',r[0].value.strip()) and len(r)>2 and r[1].value==1 and r[2].value==2]
        row['sheets'].append({'name':s.title,'rows':s.max_row,'cols':s.max_column,'charts':len(s._charts),'images':len(s._images),'comments':comments,'errors':errors,'raw_block_count':len(heads),'raw_heads':heads})
        dump.append('\n### '+s.title)
        upto=min(s.max_row,85 if heads else 130)
        for rr in s.iter_rows(max_row=upto):
            txt=['%s=%s'%(c.coordinate,str(c.value)) for c in rr if c.value is not None]
            if txt: dump.append(' | '.join(txt))
        if comments: dump.append('COMMENTS '+json.dumps(comments,ensure_ascii=False))
    (ROOT/(path.stem+'_cell_dump.txt')).write_text('\n'.join(dump),encoding='utf-8')
    inventory.append(row)
(ROOT/'source_manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
(ROOT/'workbook_inventory.json').write_text(json.dumps(inventory,indent=2,ensure_ascii=False,default=str),encoding='utf-8')
for r in inventory:
    print(r['name'],r['sha256'])
    if 'comparison_to_previous' in r: print('COMPARISON',json.dumps(r['comparison_to_previous'],ensure_ascii=False)[:3500])
    for s in r['sheets']: print('  SHEET',s['name'],s['rows'],s['cols'],'rawblocks',s['raw_block_count'],'errors',len(s['errors']),'comments',len(s['comments']))
