"""Conditional, run-stratified model comparisons. Run after extract_runs.py.

Inputs are observed well records, not figures or manually calculated growth rates.
No molecular identity, independent-culture provenance or numeric dose mapping is inferred.
All reported resampling/holdouts are within the supplied runs, not biological validation.
"""
from pathlib import Path
import json,sys,platform
import numpy as np
import pandas as pd
from scipy.optimize import least_squares,minimize,minimize_scalar
from scipy.special import expit
from scipy.signal import lfilter
from scipy.integrate import quad
import scipy
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'results';FIG=ROOT/'figures';FIG.mkdir(exist_ok=True)
df=pd.read_csv(OUT/'raw_tidy.csv',dtype={'run':str,'code':str}).fillna({'code':''})
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
COLORS=['#666666','#0072b2','#009e73','#e69f00','#d55e00','#8a4da8'];CODES=list('0ABCDE')
def save(fig,name):
    for ext in ['png','pdf']:fig.savefig(FIG/(name+'.'+ext),bbox_inches='tight',dpi=150)
    plt.close(fig)
def logistic(t,p):
    N0,mu,K,lag=p
    return K/(1+(K/N0-1)*np.exp(-mu*np.maximum(np.asarray(t)-lag,0)))
def fit_growth(t,y):
    valid=np.isfinite(y);ts=t[valid];ys=y[valid];runs=[]
    for lag in [0.,.8,1.8,3.]:
        r=least_squares(lambda p:logistic(ts,p)-ys,[np.clip(ys[0],.0001,.18),1.5,max(.3,ys.max()),lag],
          bounds=([1e-6,.01,.25,0],[.2,8,2,5]),xtol=1e-10,ftol=1e-10,gtol=1e-10,max_nfev=2500)
        runs.append(r)
    r=min(runs,key=lambda r:sum(r.fun**2))
    return r.x,float(np.sqrt(np.mean(r.fun**2))),bool(r.success)
def filtered(src,dt,k):
    z=k*dt
    if abs(z)<1e-5:A=dt*(1-z/2+z*z/6-z**3/24);wn=dt*(.5-z/6+z*z/24-z**3/120)
    else:A=-np.expm1(-z)/k;wn=(dt-A)/z
    return np.r_[0.,lfilter([1.],[1.,-np.exp(-z)],(A-wn)*src[:-1]+wn*src[1:])]
def shape(t,p,loss,m=1.,law='GM',ngrid=1601):
    tg=np.linspace(0,t[-1],ngrid);N=logistic(tg,p)
    src=N if law=='BP' else N*(1-N/p[2])
    if law=='GM_off_lag':src=np.where(tg<=p[3],0.,src)
    return np.interp(t,tg,filtered(src,tg[1],loss)-filtered(src,tg[1],loss+m))
def fit_rep(t,y,p,m=1.,upper=1.,law='GM'):
    def at(d,full=False):
        h=shape(t,p,d,m,law);a=max(float(h@y/max(h@h,1e-30)),0.);pred=a*h
        rmse=float(np.sqrt(np.mean((pred-y)**2)))
        return (rmse,a,pred) if full else rmse
    # Scan the whole permitted interval, then refine around the best grid point.
    grid=np.linspace(0,upper,31);ii=int(np.argmin([at(x) for x in grid]))
    lo=grid[max(0,ii-1)];hi=grid[min(30,ii+1)]
    r=minimize_scalar(at,bounds=(lo,hi),method='bounded',options={'xatol':1e-9})
    loss=min([0.,r.x,upper],key=at);rmse,a,pred=at(loss,True)
    resid=y-pred
    return {'amplitude':a,'loss_per_h':loss,'rmse_RFU':rmse,'boundary':loss<1e-6 or upper-loss<1e-6,
       'residual_lag1_correlation':float(np.corrcoef(resid[:-1],resid[1:])[0,1]) if np.std(resid)>0 else np.nan},pred
def hill(x,K,n):
    x=np.asarray(x,dtype=float);out=np.zeros_like(x);sel=x>0
    out[sel]=expit(n*(np.log(x[sel])-np.log(K)));return out
def fit_dose(x,y,b,model):
    x=np.asarray(x);y=np.asarray(y);scale=max(float(np.max(abs(y))),1.)
    def at(theta,full=False):
        pars=[]
        if model=='zero_dose':h=np.zeros_like(x)
        elif model=='linear':h=x/400
        elif model=='power':pars=[float(np.exp(theta[0]))];h=(x/400)**pars[0]
        else:pars=list(np.exp(theta));h=hill(x,*pars)
        a=max(float(h@(y-b)/max(h@h,1e-30)),0.);pred=b+a*h;rss=float(sum((pred-y)**2))
        return (rss,a,pars,pred) if full else rss/scale**2
    if model in ['linear','zero_dose']:theta=[];success=True
    else:
        bounds=[(np.log(.25),np.log(6))] if model=='power' else [(np.log(.1),np.log(1e4)),(np.log(.25),np.log(6))]
        starts=[[np.log(n)] for n in [1,2,4]] if model=='power' else [np.log([k,n]) for k in [40,200,800,3000] for n in [1,3]]
        opts=[minimize(at,s,method='L-BFGS-B',bounds=bounds,options={'ftol':1e-12,'gtol':1e-8,'maxiter':500}) for s in starts]
        opt=min(opts,key=lambda r:r.fun);theta=opt.x;success=bool(opt.success)
    rss,a,pars,pred=at(theta,True)
    def predict(z):
        z=np.asarray(z)
        return b+a*(np.zeros_like(z) if model=='zero_dose' else z/400 if model=='linear' else (z/400)**pars[0] if model=='power' else hill(z,*pars))
    return {'baseline_RFU':b,'amplitude_RFU':a,'K_nM':pars[0] if model=='Hill' else np.nan,'n':pars[-1] if pars else np.nan,
      'rmse_RFU':float(np.sqrt(rss/len(y))),'converged':success},predict

groups={};wellrows=[];groupstats=[]
for (run,well),z in df.groupby(['run','well']):
    z=z.sort_values('cycle');od=z.od_two.to_numpy();f=z.F_RFU.to_numpy();t=z.t_h.to_numpy()
    row={'run':run,'well':well,'label':z.label.iloc[0],'code':z.code.iloc[0],'dose_nM':z.dose_nM.iloc[0],
      'od_initial':od[0],'od_endpoint':od[-1],'od_peak':np.nanmax(od),'od_peak_to_end':np.nanmax(od)-od[-1],
      'F_initial':f[0],'F_endpoint':f[-1],'F_net_change':f[-1]-f[0],'F_peak_rise':max(f)-f[0],'F_full_range':np.ptp(f),'F_peak_time_h':t[np.argmax(f)]}
    for tt in [5.,9.]:row[f'F_rise_{tt:g}h']=np.interp(tt,t,f)-f[0]
    # Descriptive first rising crossing of a shared measured OD proxy, not per-cell calibration.
    for target in [.2,.3]:
        ok=np.where((od[:-1]<target)&(od[1:]>=target))[0]
        row[f'F_at_OD{target}_raw']=np.nan;row[f'F_at_OD{target}_rise']=np.nan
        if len(ok):
            i=ok[0];v=f[i]+(f[i+1]-f[i])*(target-od[i])/(od[i+1]-od[i])
            row[f'F_at_OD{target}_raw']=v;row[f'F_at_OD{target}_rise']=v-f[0]
    wellrows.append(row)
for key,z in df[df.code!=''].groupby(['run','label','code']):
    run,label,code=key
    od=z.pivot(index='t_h',columns='well',values='od_two');allod=z.pivot(index='t_h',columns='well',values='od_all')
    F=z.pivot(index='t_h',columns='well',values='F_RFU');F=F-F.iloc[0]
    # A mean with fewer wells is not silently substituted into the fit.
    odmean=od.mean(axis=1).where(od.count(axis=1)==od.shape[1])
    g={'t':od.index.to_numpy(),'od':odmean.to_numpy(),'allod':allod.mean(axis=1).to_numpy(),'f':F.mean(axis=1).to_numpy(),
      'fsd':F.std(axis=1,ddof=1).to_numpy(),'rep_f':F.to_numpy(),'dose':z.dose_nM.iloc[0],'wells':list(od.columns)}
    groups[key]=g
    groupstats.append({'run':run,'label':label,'code':code,'dose_nM':g['dose'],'n_wells':od.shape[1],
      'od_end':g['od'][-1],'od_peak':np.nanmax(g['od']),'od_peak_to_end':np.nanmax(g['od'])-g['od'][-1],
      'F_net_change_RFU':g['f'][-1],'F_peak_rise_RFU':max(g['f']),'F_full_range_RFU':np.ptp(g['f']),
      'F_peak_time_h':g['t'][np.argmax(g['f'])],'mean_well_SD_RFU':g['fsd'].mean(),
      'F_rise_5h':np.interp(5,g['t'],g['f']),'F_rise_9h':np.interp(9,g['t'],g['f'])})
pd.DataFrame(wellrows).to_csv(OUT/'well_summary.csv',index=False)
pd.DataFrame(groupstats).to_csv(OUT/'group_summary.csv',index=False)
growth=[];gps={};preds={};reporter=[]
cases=[('two_b009','od',.09),('two_b008','od',.08),('two_b000','od',0.),('all_b009','allod',.09)]
for case,field,offset in cases:
    for key,g in groups.items():
        p,rmse,ok=fit_growth(g['t'],g[field]-offset);gps[(case,*key)]=p
        growth.append(dict(zip(['run','label','code'],key),case=case,N0_OD=p[0],mu_per_h=p[1],K_OD=p[2],lag_h=p[3],rmse_OD=rmse,converged=ok,
          lag_boundary=p[3]<1e-5 or p[3]>4.9999,K_boundary=p[2]<.25001 or p[2]>1.9999,N0_boundary=p[0]<1.01e-6 or p[0]>.19999))
        specs=[(1.,1.,'GM'),(1.,1.,'BP')]
        if case=='two_b009':specs +=[(1.,.15,'GM'),(1.,.15,'BP'),(1.,10.,'GM'),(1.,10.,'BP'),(.5,1.,'GM'),(.5,1.,'BP'),(2.,1.,'GM'),(2.,1.,'BP'),(1.,1.,'GM_off_lag')]
        for m,upper,law in specs:
            rr,pr=fit_rep(g['t'],g['f'],p,m,upper,law)
            reporter.append(dict(zip(['run','label','code'],key),case=case,m_per_h=m,loss_upper=upper,law=law,**rr))
            if case=='two_b009' and m==1 and upper==1:preds[(*key,law)]=pr
    pd.DataFrame(growth).to_csv(OUT/'growth_fits.csv',index=False)
    pd.DataFrame(reporter).to_csv(OUT/'reporter_fits.csv',index=False)
    print('Completed growth/reporter preprocessing',case,flush=True)

# Adaptive-quadrature cross-check spans different runs and a high loss value.
checks=[]
for key in [k for k in groups if k[2]=='E' and k[1] in ['pMH45','pVIS7']]:
    g=groups[key];p=gps[('two_b009',*key)];t=g['t'];d=.3;h=shape(t,p,d)
    def fun(u,tt):
        n=logistic(u,p);return n*(1-n/p[2])*np.exp(-d*(tt-u))*(-np.expm1(-(tt-u)))
    exact=np.array([quad(fun,0,tt,args=(tt,),points=[p[3]] if 0<p[3]<tt else None,epsabs=1e-11)[0] for tt in t])
    checks.append({'group':list(key),'max_abs':float(max(abs(h-exact))),'relative_to_max':float(max(abs(h-exact))/max(exact))})
assert max(z['relative_to_max'] for z in checks)<2e-4

dosefits=[];holds=[];dosepred={}
for run,label in sorted({k[:2] for k in groups}):
    gg=[groups[(run,label,c)] for c in CODES];doses=np.array([g['dose'] for g in gg])
    if not np.isfinite(doses).all():continue
    for readout in ['5h','9h','endpoint']:
        t0=5 if readout=='5h' else 9 if readout=='9h' else gg[0]['t'][-1]
        yy=np.array([np.interp(t0,g['t'],g['f']) for g in gg]);b=yy[0]
        for model in ['zero_dose','linear','power','Hill']:
            rr,pr=fit_dose(doses[1:],yy[1:],b,model);errs=[]
            dosepred[(run,label,readout,model)]=pr
            for j in range(1,6):
                keep=[i for i in range(1,6) if i!=j]
                rf,pf=fit_dose(doses[keep],yy[keep],b,model);v=float(pf([doses[j]])[0]);errs.append(v-yy[j])
                holds.append({'run':run,'label':label,'readout':readout,'model':model,'dose_nM':doses[j],'observed':yy[j],'predicted':v,'error':v-yy[j]})
            dosefits.append({'run':run,'label':label,'readout':readout,'time_h':t0,'model':model,**rr,'held_dose_rmse_RFU':float(np.sqrt(np.mean(np.array(errs)**2)))})
    print('Completed dose checks',run,label,flush=True)
    pd.DataFrame(dosefits).to_csv(OUT/'dose_model_comparison.csv',index=False)
    pd.DataFrame(holds).to_csv(OUT/'dose_holdout_predictions.csv',index=False)

# A directly comparable test of transferring the same recorded pMH45 label between normal-labelled runs.
# No refitting on the target run: this tests portability, not independent biological replication.
transfer=[]
for origin,target in [('20260910','20260930'),('20260930','20260910')]:
    for readout,tt in [('5h',5.),('9h',9.)]:
        yy=np.array([np.interp(tt,groups[(target,'pMH45',c)]['t'],groups[(target,'pMH45',c)]['f']) for c in CODES])
        for model in ['zero_dose','linear','power','Hill']:
            pred=dosepred[(origin,'pMH45',readout,model)]([0,8,40,200,300,400])
            transfer.append({'source_run':origin,'target_run':target,'readout':readout,'model':model,
              'transfer_rmse_RFU':float(np.sqrt(np.mean((pred-yy)**2))),
              'target_mean_positive_response_RFU':float(np.mean(yy[1:]))})
pd.DataFrame(transfer).to_csv(OUT/'cross_run_transfer.csv',index=False)

for run in sorted(df.run.unique()):
    names=sorted({k[1] for k in groups if k[0]==run});nr=len(names)
    fig,axs=plt.subplots(nr,3,figsize=(15,3.1*nr),layout='constrained',squeeze=False)
    for j,name in enumerate(names):
        for code,col in zip(CODES,COLORS):
            g=groups[(run,name,code)];t=g['t'];p=gps[('two_b009',run,name,code)]
            lab=f"{g['dose']:g} nM" if np.isfinite(g['dose']) else 'code '+code
            axs[j,0].plot(t,g['od']-.09,'.',color=col,ms=3);axs[j,0].plot(t,logistic(t,p),color=col,label=lab)
            axs[j,1].plot(t,g['f'],'.',color=col,ms=3);axs[j,1].plot(t,preds[(run,name,code,'GM')],color=col)
            axs[j,2].plot(t,g['f']-preds[(run,name,code,'GM')],color=col)
        for k,ttl in enumerate(['Growth fit','Reporter fit','Reporter residual']):
            axs[j,k].set_title(name+' | '+ttl);axs[j,k].set_xlabel('Hours after first reading');axs[j,k].grid(alpha=.15)
        axs[j,0].set_ylabel('OD minus assumed 0.09');axs[j,1].set_ylabel('RFU minus own initial');axs[j,2].set_ylabel('Observed - fitted RFU')
    axs[0,0].legend(ncol=3,fontsize=8)
    fig.suptitle(run+' | conditional fits, assumed maturation 1/h; apparent loss 0-1/h',fontsize=14)
    save(fig,'trajectories_'+run)
    if run=='20261002':continue
    fig,axs=plt.subplots(2,nr,figsize=(3.7*nr,7.5),layout='constrained',squeeze=False)
    for j,name in enumerate(names):
        for row,(readout,tt) in enumerate([('5h',5.),('9h',9.)]):
            vals=[];sds=[]
            for code in CODES:
                g=groups[(run,name,code)];reps=np.array([np.interp(tt,g['t'],g['rep_f'][:,i]) for i in range(3)])
                vals.append(reps.mean());sds.append(reps.std(ddof=1))
            ax=axs[row,j];ax.errorbar([0,8,40,200,300,400],vals,yerr=sds,fmt='o',color='black',capsize=3)
            for model,col in [('linear','#777777'),('power','#d55e00'),('Hill','#0072b2')]:
                x=np.linspace(0,400,201);ax.plot(x,dosepred[(run,name,readout,model)](x),label=model,color=col)
            ax.set_title(name+' | '+readout);ax.set_xlabel('Nominal added Cd (nM)');ax.set_ylabel('Initial-subtracted RFU');ax.grid(alpha=.15)
    axs[0,0].legend(fontsize=9);fig.suptitle(run+' | dots: mean +/- sample SD across 3 wells; curves: fitted descriptions')
    save(fig,'dose_response_'+run)

gr=pd.DataFrame(growth);rp=pd.DataFrame(reporter);dc=pd.DataFrame(dosefits)
comparisons=[]
for (run,case,m,upper),z in rp[rp.law.isin(['GM','BP'])].groupby(['run','case','m_per_h','loss_upper']):
    p=z.pivot(index=['label','code'],columns='law',values='rmse_RFU');ratio=p.BP/p.GM
    comparisons.append({'run':run,'case':case,'m_per_h':m,'loss_upper':upper,'groups':len(p),'GM_lower_RMSE':int((ratio>1+1e-6).sum()),
      'BP_lower_RMSE':int((ratio<1-1e-6).sum()),'BP_GM_ratio_min':ratio.min(),'BP_GM_ratio_max':ratio.max(),
      'GM_boundary':int(z[z.law=='GM'].boundary.sum()),'BP_boundary':int(z[z.law=='BP'].boundary.sum())})
pd.DataFrame(comparisons).to_csv(OUT/'reporter_comparison_summary.csv',index=False)
manifest={'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'pandas':pd.__version__,
 'n_runs':5,'groups':len(groups),'growth_fits':len(growth),'reporter_fits':len(reporter),'dose_models':len(dosefits),
 'holdout_predictions':len(holds),'quadrature_checks':checks,'primary_offset':.09,'primary_maturation':1.,'primary_loss_bounds':[0,1],
 'uncertainty':'Across-well sample SD only; no claim of independent biological replicates or parameter confidence intervals',
 'unknown_dose_run':'20261002: condition-code trajectories fitted, numeric dose-response excluded',
 'missing_OD':'20260930 A6 cycle35: no imputation; primary group-mean OD at that time excluded from growth fitting',
 'loss_search':'31-point interval scan followed by bounded scalar refinement around the best grid value; endpoints checked',
 'growth_bounds':{'N0':[1e-6,.2],'mu':[.01,8],'K':[.25,2],'lag':[0,5]},
 'dose_bounds':{'K_nM':[.1,10000],'n':[.25,6]},'main_growth_windows':'All available complete-group time points; post-peak decline not represented by logistic'}
(OUT/'analysis_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print('ALL COMPLETE',json.dumps({k:v for k,v in manifest.items() if k in ['groups','growth_fits','reporter_fits','dose_models','holdout_predictions']}),flush=True)
