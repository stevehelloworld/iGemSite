"""Check run overlap, permissive growth bounds, and conditional Hill profiles."""
from pathlib import Path
import ast,json,sys
import numpy as np
import pandas as pd
from scipy.optimize import least_squares,minimize,minimize_scalar
from scipy.special import expit
from scipy.signal import lfilter
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'results';FIG=ROOT/'figures'
# Reuse the exact, saved functions without rerunning analysis at import time.
tree=ast.parse((ROOT/'analyze.py').read_text(encoding='utf-8'))
defs=[n for n in tree.body if isinstance(n,ast.FunctionDef)]
exec(compile(ast.Module(body=defs,type_ignores=[]),'analyze_functions','exec'),globals())
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False})
df=pd.read_csv(OUT/'raw_tidy.csv',dtype={'run':str,'code':str});gf=pd.read_csv(OUT/'growth_fits.csv',dtype={'run':str,'code':str})
codes=list('0ABCDE');groups={}
for key,z in df[df.code.notna()].groupby(['run','label','code']):
    od=z.pivot(index='t_h',columns='well',values='od_two');f=z.pivot(index='t_h',columns='well',values='F_RFU');f=f-f.iloc[0]
    groups[key]={'t':od.index.to_numpy(),'y':od.mean(axis=1).where(od.count(axis=1)==od.shape[1]).to_numpy()-.09,'f':f.mean(axis=1).to_numpy()}

# Exact channel-vector reuse checks are independent of differing time stamps.
duplicate_rows=[];vectors={}
for (run,well),z in df.groupby(['run','well']):
    z=z.sort_values('cycle')
    for channel,cols in [('OD',['od_pos0','od_pos1','od_pos2']),('F',['F_pos0','F_pos1'])]:
        v=z[cols].to_numpy().tobytes();key=(channel,v)
        for or_run,or_well in vectors.get(key,[]):
            if or_run!=run:duplicate_rows.append({'run1':or_run,'well1':or_well,'run2':run,'well2':well,'channel':channel})
        vectors.setdefault(key,[]).append((run,well))
pd.DataFrame(duplicate_rows,columns=['run1','well1','run2','well2','channel']).to_csv(OUT/'cross_run_exact_duplicates.csv',index=False)

# Repeat any primary growth fit touching a bound, using N0 and a positive capacity gap.
# This is a sensitivity check; an unobserved plateau remains unobserved.
relaxed=[];r_reps=[]
primary=gf[gf['case']=='two_b009']
flagged=primary[primary.lag_boundary|primary.K_boundary|primary.N0_boundary]
for _,row in flagged.iterrows():
    key=(row.run,row.label,row.code);g=groups[key];ok=np.isfinite(g['y']);t=g['t'][ok];y=g['y'][ok]
    def unpack(q):return np.array([q[0],q[1],q[0]+q[2],q[3]])
    runs=[]
    for lag in [0.,1.,3.,min(6.,t[-1]-.1)]:
        n0=np.clip(y[0],.0001,.18);gap=max(.01,np.nanmax(y)-n0)
        fit=least_squares(lambda q:logistic(t,unpack(q))-y,[n0,row.mu_per_h,gap,lag],bounds=([1e-6,.001,1e-5,0],[.3,10,10,t[-1]]),max_nfev=5000,xtol=1e-11,ftol=1e-11,gtol=1e-11)
        runs.append(fit)
    r=min(runs,key=lambda r:sum(r.fun**2));p=unpack(r.x);rmse=np.sqrt(np.mean(r.fun**2))
    relaxed.append({'run':row.run,'label':row.label,'code':row.code,'old_mu':row.mu_per_h,'old_K':row.K_OD,'old_lag':row.lag_h,'old_rmse':row.rmse_OD,
      'new_N0':p[0],'new_mu':p[1],'new_K':p[2],'new_lag':p[3],'new_rmse':rmse,'capacity_gap_at_upper_bound':r.x[2]>9.999,'converged':bool(r.success)})
    for law in ['GM','BP']:
        rr,_=fit_rep(g['t'],g['f'],p,law=law)
        r_reps.append({'run':row.run,'label':row.label,'code':row.code,'law':law,**rr})
pd.DataFrame(relaxed).to_csv(OUT/'growth_relaxed_bounds.csv',index=False)
pd.DataFrame(r_reps).to_csv(OUT/'reporter_relaxed_growth.csv',index=False)

# Profiles indicate assumption-conditioned fit sensitivity, not confidence intervals.
selected=[('20260910','pMH45'),('20260930','pMH45'),('20260927','pVIS1'),('20260930','pVIS8')]
profiles=[]
for run,label in selected:
    yy=np.array([np.interp(5,groups[(run,label,c)]['t'],groups[(run,label,c)]['f']) for c in codes]);x=np.array([8,40,200,300,400]);b=yy[0];y=yy[1:]
    for K in np.geomspace(.1,1e4,71):
        def at(n,full=False):
            h=hill(x,K,n);a=max(float(h@(y-b)/(h@h)),0.);rss=sum((b+a*h-y)**2)
            return (np.sqrt(rss/5),a) if full else rss
        grid=np.linspace(.25,6,31);i=np.argmin([at(n) for n in grid]);lo=grid[max(0,i-1)];hi=grid[min(30,i+1)]
        r=minimize_scalar(at,bounds=(lo,hi),method='bounded');n=min([.25,r.x,6],key=at);rmse,a=at(n,True)
        profiles.append({'run':run,'label':label,'time_h':5,'K_nM':K,'n':n,'amplitude':a,'rmse_RFU':rmse})
pd.DataFrame(profiles).to_csv(OUT/'hill_profiles_5h.csv',index=False)

fig,axs=plt.subplots(1,2,figsize=(11,4.3),layout='constrained')
for run,col in [('20260910','#0072b2'),('20260930','#d55e00')]:
    yy=np.array([np.interp(5,groups[(run,'pMH45',c)]['t'],groups[(run,'pMH45',c)]['f']) for c in codes]);xx=np.array([0,8,40,200,300,400]);fit,pred=fit_dose(xx[1:],yy[1:],yy[0],'Hill')
    axs[0].plot(xx,yy,'o',color=col,label=run+' observations');tt=np.linspace(0,400,200);axs[0].plot(tt,pred(tt),color=col,label=run+' fitted Hill')
axs[0].set(xlabel='Nominal added Cd (nM)',ylabel='Initial-subtracted fluorescence (RFU)',title='pMH45 | matched 5-hour readout');axs[0].legend(fontsize=8)
trs=pd.read_csv(OUT/'cross_run_transfer.csv');z=trs[(trs.readout=='5h')&(trs.source_run==20260910)&(trs.model!='zero_dose')]
axs[1].bar(z.model,z.transfer_rmse_RFU,color=['#777777','#e69f00','#0072b2']);axs[1].set(ylabel='Prediction RMSE on September 30 (RFU)',title='Fit September 10; predict September 30')
fig.suptitle('A cross-run portability check; biological independence and protocol matching unconfirmed')
save(fig,'cross_run_transfer')

fig,axs=plt.subplots(1,2,figsize=(11,4.4),layout='constrained')
for ax,run in zip(axs,['20260928','20260930']):
    for code,col in zip(codes,['#666666','#0072b2','#009e73','#e69f00','#d55e00','#8a4da8']):
        g=groups[(run,'pVIS7',code)];ax.plot(g['t'],g['y'],'.-',label={'0':'0','A':'8','B':'40','C':'200','D':'300','E':'400'}[code]+' nM',color=col,ms=4)
    ax.set(title=run+' | pVIS7',xlabel='Hours after first reading',ylabel='OD minus assumed 0.09');ax.legend(ncol=2,fontsize=8);ax.grid(alpha=.15)
fig.suptitle('Growth trajectories differ at higher doses; OD is not a viability or removal measurement')
save(fig,'pvis7_growth')

fig,axs=plt.subplots(2,2,figsize=(10,7),layout='constrained')
pr=pd.DataFrame(profiles)
for ax,(run,label) in zip(axs.flat,selected):
    z=pr[(pr.run==run)&(pr.label==label)];ax.semilogx(z.K_nM,z.rmse_RFU/z.rmse_RFU.min());ax.axvspan(8,400,alpha=.12,color='grey')
    ax.set(title=run+' | '+label,xlabel='Fixed Hill K (nM)',ylabel='RMSE / best scanned RMSE',ylim=(.99,5));ax.grid(alpha=.15)
fig.suptitle('Conditional 5-hour K profiles; shaded range: positive doses tested; not uncertainty intervals')
save(fig,'hill_profiles')

manifest={'exact_reused_channel_vectors_between_runs':len(duplicate_rows),'relaxed_primary_growth_fits':len(relaxed),
 'relaxed_bounds':{'N0':[1e-6,.3],'mu':[.001,10],'positive_capacity_gap':[1e-5,10],'lag':'[0, end time]'},
 'profile_points':len(profiles),'profile_caution':'Deterministic sensitivity with fixed preprocessing/baseline/readout; not confidence intervals'}
(OUT/'extended_checks.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print(json.dumps(manifest),flush=True)
print(pd.DataFrame(relaxed).to_string(index=False),flush=True)
