"""Read sequence-map annotations; distinguish design files from experimental validation."""
from pathlib import Path
import struct,json,xml.etree.ElementTree as ET,re,hashlib,sys,csv
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'results';records=[];features=[];seqs={}
for path in sorted((ROOT/'experiment_source').rglob('*.dna')):
    data=path.read_bytes();pos=0;seq='';fs=[];notes={}
    while pos+5<=len(data):
        kind=data[pos];size=struct.unpack('>I',data[pos+1:pos+5])[0];body=data[pos+5:pos+5+size];pos+=5+size
        if kind==0:seq=body[1:].decode('ascii').upper()
        if body.lstrip().startswith(b'<'):
            try:rt=ET.fromstring(body.decode('utf-8'))
            except (ET.ParseError,UnicodeDecodeError):continue
            if kind==6 and rt.tag=='Notes':notes={x.tag:x.text for x in rt}
            if kind!=10:continue
            for f in rt.iter('Feature'):
                segs=[s.attrib for s in f.iter('Segment')];qs=[]
                for q in f.iter('Q'):
                    vals=[' '.join(v.attrib.values()) for v in q.iter('V')]
                    qs.append(q.attrib.get('name','')+': '+'; '.join(vals))
                row={'file':path.name,'name':f.attrib.get('name',''),'type':f.attrib.get('type',''),
                  'directionality':f.attrib.get('directionality',''),'segments':segs,'qualifiers':qs}
                fs.append(row)
    rec={'file':path.name,'path':str(path),'length_bp':len(seq),'sha256_sequence':hashlib.sha256(seq.encode()).hexdigest(),'notes':notes,'features':fs}
    records.append(rec);features.extend(fs);seqs[path.stem]=seq
    print(path.name,len(seq),'FEATURES',[f['name'] for f in fs],flush=True)

pairs=[]
for a,b in [(1,5),(2,6),(3,7),(4,8)]:
    long=seqs['pVIS'+str(a)];short=seqs['pVIS'+str(b)];gap=len(long)-len(short)
    start=next((i for i,(x,y) in enumerate(zip(long,short)) if x!=y),len(short))
    exact=long[:start]+long[start+gap:]==short
    pairs.append({'display_design':'pVIS'+str(a),'anchor_deleted_design':'pVIS'+str(b),'length_difference_bp':gap,
       'exact_single_deletion_same_origin':exact,'matches_annotated_anchor_deletion_5917_6306':long[:5916]+long[6306:]==short,
       'deletion_start_1based':start+1 if exact else None,'deletion_end_1based':start+gap if exact else None})
print('PAIR COMPARISONS',json.dumps(pairs))
(ROOT/'construct_annotations.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'construct_pair_comparison.json').write_text(json.dumps(pairs,indent=2),encoding='utf-8')
with (OUT/'construct_features.csv').open('w',encoding='utf-8-sig',newline='') as f:
    wr=csv.DictWriter(f,fieldnames=['file','name','type','directionality','segments','qualifiers']);wr.writeheader();wr.writerows(features)
