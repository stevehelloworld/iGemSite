"""Extract raw Tecan measurements and documented maps; no source edits."""
from pathlib import Path
import json,re,hashlib,sys
import numpy as np
import pandas as pd
import openpyxl
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'results';OUT.mkdir(exist_ok=True)
INV=json.loads((ROOT/'workbook_inventory.json').read_text(encoding='utf-8'))
FIELDS=['Time [s]','Temp. [°C]','Mean','StDev','0;1','1;1','2;1','0;0','1;0']
def parse(path):
    w=openpyxl.load_workbook(path,data_only=True)
    maps=[];dosekey={};blocks={};settings={};headers=[]
    for s in w:
        for row in s:
            if len(row)>12 and [c.value for c in row[1:13]]==list(range(1,13)):
                r=row[0].row
                if [s.cell(r+i,1).value for i in range(1,9)]==list('ABCDEFGH'):
                    cells=[s.cell(r+i,j) for i in range(1,9) for j in range(2,14)]
                    n=sum(bool(re.fullmatch(r'p(?:VIS\d+|MH45)-[0A-E]',str(c.value))) for c in cells)
                    if n: maps.append((n,s,r))
            for c in row:
                if c.value=='Cd(nM)':
                    for rr in range(c.row+1,c.row+7):
                        code=str(s.cell(rr,c.column-1).value);v=s.cell(rr,c.column).value
                        if code in list('0ABCDE') and isinstance(v,(int,float)):dosekey[code]=float(v)
        heads=[c.row for (c,*rest) in s if isinstance(c.value,str) and re.fullmatch(r'[A-H](?:[1-9]|1[0-2])',c.value.strip()) and len(rest)>1 and rest[0].value==1 and rest[1].value==2]
        if heads:
            settings={'sheet':s.title,'date':str(s['B5'].value),'start_time':str(s['B50'].value),'target':str(s['F14'].value),
              'gain':s['E43'].value,'excitation_nm':s['E39'].value,'emission_nm':s['E40'].value,'plate':s['E11'].value,
              'kinetic_cycles_setting':s['E27'].value,'plate_selection':s['E49'].value}
        for i,r in enumerate(heads):
            well=s.cell(r,1).value.strip();n=0
            while s.cell(r,n+2).value==n+1:n+=1
            fs={}
            for j in range(r+1,heads[i+1] if i+1<len(heads) else s.max_row+1):
                k=s.cell(j,1).value
                if k in FIELDS:
                    assert k not in fs,(path,well,k)
                    fs[k]={'row':j,'values':[s.cell(j,c).value for c in range(2,n+2)]}
            channel='OD' if '2;1' in fs else 'F'
            assert (well,channel) not in blocks
            blocks[(well,channel)]={'fields':fs,'n':n,'sheet':s.title}
    if not blocks:return None
    n,s,r=max(maps,key=lambda x:x[0]);mapping={}
    for i in range(1,9):
        for j in range(2,14):
            c=s.cell(r+i,j);v=c.value
            if v is not None:
                well='ABCDEFGH'[i-1]+str(j-1)
                match=re.fullmatch(r'(pVIS\d+|pMH45)-([0A-E])',str(v))
                mapping[well]={'label':match[1] if match else str(v),'code':match[2] if match else '',
                              'dose_nM':dosekey.get(match[2],np.nan) if match else np.nan,'map_ref':s.title+'!'+c.coordinate}
    return w,mapping,blocks,dosekey,settings

rows=[];runs=[];maps=[];rawhash={}
for rec in sorted(INV,key=lambda z:z['name']):
    path=Path(rec['path']);parsed=parse(path)
    if parsed is None:
        runs.append({'run':path.name[:8],'filename':path.name,'status':'layout_only_no_raw_measurements','measured_wells':0})
        continue
    wb,mapping,blocks,dosekey,settings=parsed
    run=path.name[:8];medium='No Na (filename)' if 'No Na' in path.name else 'Normal (filename/plot label)'
    wells=sorted({k[0] for k in blocks});temps=[];canonical=[];meanerrs=[];missing=[]
    for well in wells:
        m=mapping[well];od=blocks[(well,'OD')];fl=blocks[(well,'F')]
        assert od['n']==fl['n']
        t=np.array(od['fields']['Time [s]']['values'],float)
        assert np.array_equal(t,fl['fields']['Time [s]']['values']) and np.all(np.diff(t)>0)
        vals={k:np.array(v['values'],float) for k,v in od['fields'].items()}
        fvals={k:np.array(v['values'],float) for k,v in fl['fields'].items()}
        for ch,arrs,b in [('OD',vals,od),('F',fvals,fl)]:
            for k,arr in arrs.items():
                for ii in np.where(~np.isfinite(arr))[0]:
                    missing.append({'well':well,'channel':ch,'field':k,'cycle':int(ii+1),'cell':b['sheet']+'!'+openpyxl.utils.get_column_letter(ii+2)+str(b['fields'][k]['row'])})
        temps.extend(vals['Temp. [°C]']);o2=(vals['1;1']+vals['2;1'])/2
        meanerrs.append(np.nanmax(abs(vals['Mean']-(vals['0;1']+vals['1;1']+vals['2;1'])/3)))
        for channel,b in [('OD',od),('F',fl)]:
            for k,v in sorted(b['fields'].items()):canonical.append([well,channel,k,v['values']])
        maps.append({'run':run,'well':well,**m,'medium':medium})
        for i,tt in enumerate(t):
            rows.append({'run':run,'well':well,**m,'medium':medium,'cycle':i+1,'t_h':tt/3600,
              'od_all':vals['Mean'][i],'od_two':o2[i],'od_pos0':vals['0;1'][i],'od_pos1':vals['1;1'][i],'od_pos2':vals['2;1'][i],
              'F_RFU':fvals['Mean'][i],'F_pos0':fvals['0;0'][i],'F_pos1':fvals['1;0'][i],
              'od_cell':od['sheet']+'!'+openpyxl.utils.get_column_letter(i+2)+str(od['fields']['Mean']['row']),
              'F_cell':fl['sheet']+'!'+openpyxl.utils.get_column_letter(i+2)+str(fl['fields']['Mean']['row'])})
    fingerprint=hashlib.sha256(json.dumps(sorted(canonical),sort_keys=True).encode()).hexdigest();rawhash[run]=fingerprint
    zz=pd.DataFrame(rows);zz=zz[zz.run==run];start=zz[zz.cycle==1];end=zz[zz.cycle==zz.cycle.max()]
    rr={'run':run,'filename':path.name,'status':'raw_measurements','measured_wells':len(wells),'main_wells':sum(bool(mapping[x]['code']) for x in wells),
       'cycles':len(t),'duration_h':t[-1]/3600,'dose_key':dosekey,'settings':settings,'temperature_range_C':[min(temps),max(temps)],
       'map_ref_example':mapping[wells[0]]['map_ref'],'raw_sha256':fingerprint,'missing_raw_values':missing,
       'min_individual_OD':min(zz.od_pos0.min(),zz.od_pos1.min(),zz.od_pos2.min()),'min_two_position_OD':zz.od_two.min(),
       'position_difference_first':(start.od_pos0-start.od_two).mean(),'position_difference_last':(end.od_pos0-end.od_two).mean(),
       'max_exported_mean_discrepancy_OD':max(meanerrs),'formula_error_counts':{s['name']:len(s['errors']) for s in rec['sheets']},
       'map_dose_codes':sorted(set(mapping[x]['code'] for x in wells if mapping[x]['code']))}
    runs.append(rr)

# Raw-channel comparison ignores inserted rows, added sheets and formula edits.
previous=Path(r'C:\Users\Francis Lin\Downloads\20260910pMH45-pVIS1234(student).xlsx')
_,pm,pb,pk,ps=parse(previous);pc=[]
for (well,ch),b in pb.items():
    for k,v in sorted(b['fields'].items()):pc.append([well,ch,k,v['values']])
oldhash=hashlib.sha256(json.dumps(sorted(pc),sort_keys=True).encode()).hexdigest()
pr=next(r for r in runs if r['run']=='20260910')
pr['previous_raw_sha256']=oldhash;pr['raw_identical_to_previous']=oldhash==rawhash['20260910']
nm={r['well']:{k:r[k] for k in ('label','code','dose_nM')} for r in maps if r['run']=='20260910'}
pr['main_map_identical_to_previous']=all(nm[k]['label']==v['label'] and nm[k]['code']==v['code'] and (not v['code'] or nm[k]['dose_nM']==v['dose_nM']) for k,v in pm.items())
df=pd.DataFrame(rows);df.to_csv(OUT/'raw_tidy.csv',index=False)
pd.DataFrame(maps).to_csv(OUT/'plate_maps.csv',index=False)
(OUT/'run_inventory.json').write_text(json.dumps(runs,indent=2,ensure_ascii=False,default=str),encoding='utf-8')
for r in runs: print(json.dumps(r,ensure_ascii=False))
print('TOTAL',len(df),'well-time rows; distinct raw fingerprints',len(set(rawhash.values())))
