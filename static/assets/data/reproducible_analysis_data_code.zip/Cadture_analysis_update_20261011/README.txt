CADTURE — EXPERIMENT ARCHIVE AND MODELLING UPDATE
Prepared 11 October 2026

START HERE
Open analysis_report.html in a browser. It includes the explanations, results,
references, assumptions, and embedded figures, and works without internet access.
Use missing_information.txt for the prioritised questions and measurements.

WHAT IS NEW
Five distinct raw plate-reader runs were analysed, with 388 measured wells and
126 main sample/condition groups. Four runs are additions to the previous
September 10 analysis. The September 10 raw readings are unchanged.
The six workbooks inside the full experiment archive contain the same cell
values, formulas and cached values as those in the plate-reader archive.
They were not counted twice.

The full archive clarifies reference construct pairings and includes construction
logs, medium recipes and partial sequencing records. In the supplied recipes,
removing added NaCl also changes yeast extract from 5 to 10 g/L. Confirm whether
those were the recipes actually used. Construct maps are not a substitute for
assay-clone verification, protein localisation or direct cadmium measurements.

User-relayed wet-lab clarification, 11 October 2026: both media contain kanamycin
and glucose (LB + kanamycin + glucose, versus LB described as without sodium +
kanamycin + glucose). Final supplement concentrations and the actual base-LB
recipes remain unconfirmed. This clarification is now in the report and checklist;
the measurements and fitted results have not changed.

CONTENTS
  analysis_report.html / .txt: full interpretation and limitations
  missing_information.txt: prioritised missing records and experiments
  figures/: 12 figures, each supplied as PNG and vector PDF
  results/raw_tidy.csv: all extracted measured channels with source-cell references
  results/plate_maps.csv: documented labels and dose mapping
  results/growth_fits.csv: all four OD representations
  results/reporter_fits.csv: maturation, loss-bound and production-law sensitivities
  results/dose_model_comparison.csv: fixed-time fits and omitted-dose prediction errors
  results/dose_holdout_predictions.csv: individual omitted-dose predictions
  results/cross_run_transfer.csv: pMH45 predictions across Normal-labelled runs
  results/growth_relaxed_bounds.csv: follow-up for boundary-affected growth fits
  results/hill_profiles_5h.csv: sensitivity profiles, not confidence intervals
  results/matched_OD_wells.csv / matched_OD_summary.csv: first OD-0.30 crossings
  results/construct_features.csv / construct_pair_comparison.json: reference-map evidence
  results/sequence_read_inventory.csv: limited base-call/quality/exact-match inventory
  source/: the six input workbooks and supplied plate-reader figures, unedited
  *_manifest.json and *_comparison.json: archive provenance and comparison records
  *.py: saved extraction, analysis, checking and report-generation workflow

REGENERATION
For the numerical fits and figures, start from the included results/raw_tidy.csv:
  python analyze.py
  python extended_checks.py
  python make_report.py
Required packages: NumPy, pandas, SciPy, Matplotlib. openpyxl is needed for
workbook extraction and archive comparison. The exact numerical environment and
fit settings are recorded in results/analysis_manifest.json.

Archive-level regeneration additionally requires the original uploaded ZIPs
and the old standalone September 10 workbook, at the paths recorded in the
manifests (or adjusted paths in the inspection scripts). To inspect the full
experiment archive, run inspect_experiments.py, then inspect_constructs.py,
then archive_evidence_checks.py. inspect_constructs.py deliberately uses only
the current feature-annotation packet in each SnapGene file; older embedded
history must not be mistaken for the current design. archive_evidence_checks.py
also regenerates the matched-OD tables.

The portable package includes the plate-reader inputs, but not a second copy of
the entire 115 MB expanded experiment archive. That archive remains available
as the user's supplied ZIP and in the local experiment_source/ folder.
The source extraction scripts preserve the original audit paths; adjust them
if regenerating on a different computer. No original workbook was edited.

INTERPRETATION
Nominal cadmium doses are documented for four runs. October 2 has condition codes
but no verified code-to-dose key, and is excluded from numerical dose fitting.
OD subtraction of 0.09 and reporter maturation of 1/h are assumptions. Across-well
SD is not a biological confidence interval. Model comparisons use the stated
bounds; they do not establish a unique biological mechanism. No validated
cadmium concentration prediction, detection limit, capture percentage or
flow-through device performance is claimed.

These are AI-assisted computational checks, not external human peer review.
The existing wiki_modeling.tex was not changed by this analysis update.
