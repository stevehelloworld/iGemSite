"""Reproducible archive checks and descriptive matched-OD summaries.

Sequence checks describe supplied reference files and local exact matches only.
They are not a full chromatogram review or certification of assay-clone identity.
"""
from pathlib import Path
import json, struct, difflib, re, sys
import numpy as np
import pandas as pd
import openpyxl

sys.stdout.reconfigure(encoding='utf-8')
ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'results'

# A missing target crossing remains missing. No extrapolation or OD calibration.
raw = pd.read_csv(OUT / 'raw_tidy.csv', dtype={'run': str, 'code': str})
rows = []
for (run, label, code, well), z in raw[raw.code.notna()].groupby(['run', 'label', 'code', 'well']):
    z = z.sort_values('t_h')
    od, tt, ff = (z[c].to_numpy() for c in ['od_two', 't_h', 'F_RFU'])
    crossing_t = crossing_f = np.nan
    if od[0] == .3:
        crossing_t, crossing_f = tt[0], ff[0]
    else:
        for j in range(1, len(z)):
            if np.isfinite(od[j-1:j+1]).all() and od[j-1] < .3 <= od[j]:
                a = (.3 - od[j-1]) / (od[j] - od[j-1])
                crossing_t = tt[j-1] + a*(tt[j]-tt[j-1])
                crossing_f = ff[j-1] + a*(ff[j]-ff[j-1])
                break
    rows.append({'run': run, 'label': label, 'code': code, 'well': well,
                 'crossing_t_h': crossing_t, 'F_raw_RFU': crossing_f,
                 'F_rise_RFU': crossing_f-ff[0]})
cross = pd.DataFrame(rows)
cross.to_csv(OUT / 'matched_OD_wells.csv', index=False)
summary = cross.groupby(['run', 'label', 'code']).agg(
    n_wells=('well', 'count'), n_crossing=('F_raw_RFU', 'count'),
    crossing_time_mean_h=('crossing_t_h', 'mean'),
    F_raw_mean_RFU=('F_raw_RFU', 'mean'), F_raw_sample_SD_RFU=('F_raw_RFU', 'std'),
    F_rise_mean_RFU=('F_rise_RFU', 'mean'), F_rise_sample_SD_RFU=('F_rise_RFU', 'std'))
summary.to_csv(OUT / 'matched_OD_summary.csv')

# Also compare cached formula values, in addition to the formula/value audit.
comparisons = []
for path in (ROOT / 'experiment_source').rglob('*.xlsx'):
    matches = list((ROOT / 'source').rglob(path.name))
    if not matches:
        continue
    def cells(p):
        wb = openpyxl.load_workbook(p, data_only=True, read_only=True)
        out = {(ws.title, c.coordinate): c.value for ws in wb for row in ws for c in row if c.value is not None}
        wb.close()
        return out
    a, b = cells(path), cells(matches[0])
    diffs = sum(a.get(k) != b.get(k) for k in a.keys() | b.keys())
    comparisons.append({'file': path.name, 'cached_value_differences': diffs})

# Sequence maps contain reference/design sequences, not measured traces.
refs = {}
for path in (ROOT / 'experiment_source').rglob('pVIS*.dna'):
    data = path.read_bytes(); pos = 0
    while pos+5 <= len(data):
        kind = data[pos]; size = struct.unpack('>I', data[pos+1:pos+5])[0]
        body = data[pos+5:pos+5+size]; pos += 5+size
        if kind == 0:
            refs[path.stem] = body[1:].decode('ascii').upper()

def abif_entries(data):
    assert data[:4] == b'ABIF'
    fmt = '>4sIHHIIII'
    directory = struct.unpack_from(fmt, data, 6)
    entries = {}
    for i in range(directory[4]):
        off = directory[6]+28*i
        name, num, typ, size, n, nbytes, loc, handle = struct.unpack_from(fmt, data, off)
        payload = data[off+20:off+20+nbytes] if nbytes <= 4 else data[loc:loc+nbytes]
        entries[(name.decode('ascii'), num)] = payload
    return entries

seq_rows = []
for path in sorted((ROOT / 'experiment_source').rglob('*.ab1')):
    entries = abif_entries(path.read_bytes())
    bases = entries.get(('PBAS', 2), entries.get(('PBAS', 1), b'')).decode('ascii').rstrip('\x00').upper()
    qual = entries.get(('PCON', 2), entries.get(('PCON', 1), b''))
    match = re.match(r'(pVIS\d+)', path.name)
    label = match.group(1) if match else None
    best = None
    if label in refs:
        for orientation, seq in [('forward', refs[label]), ('reverse-complement', refs[label].translate(str.maketrans('ACGT', 'TGCA'))[::-1])]:
            m = difflib.SequenceMatcher(None, bases, seq+seq, autojunk=False).find_longest_match()
            if best is None or m.size > best[0].size:
                best = (m, orientation)
    m, orientation = best if best else (None, None)
    seq_rows.append({'file': str(path.relative_to(ROOT / 'experiment_source')),
                     'named_reference': label, 'called_bases': len(bases),
                     'quality_values': len(qual), 'bases_Q20_or_more': sum(q >= 20 for q in qual),
                     'longest_exact_reference_match_bp': m.size if m else None,
                     'match_read_start_1based': m.a+1 if m else None,
                     'match_orientation': orientation,
                     'scope': 'local exact-match summary; no complete clone or chromatogram certification'})
pd.DataFrame(seq_rows).to_csv(OUT / 'sequence_read_inventory.csv', index=False)

result = {'cached_workbook_comparisons': comparisons,
          'matched_OD_target': .3, 'matched_OD_representation': 'mean of positions 1;1 and 2;1, no offset subtraction',
          'matched_OD_counts': [{'run': run, 'n_wells': len(z), 'n_crossing': int(z.F_raw_RFU.notna().sum())} for run, z in cross.groupby('run')],
          'ab1_files': len(seq_rows),
          'sequence_scope': 'Reference maps and local exact matches are not full experimental validation. Linking a selected clone to each assay remains required.'}
(OUT / 'archive_evidence_checks.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result, indent=2))
print(pd.DataFrame(seq_rows).drop(columns=['file', 'scope']).to_string(index=False))
