This is one of three companion archives from the complete Cadture reproducible analysis bundle. Download all three files and extract them into the same destination folder; each archive uses the shared top-level folder Cadture_analysis_update_20261011.

Parts: reproducible_analysis_data_code.zip (source records, scripts, extracted observations and results); reproducible_analysis_report.zip (HTML report); reproducible_analysis_figures.zip (report figures). The README.txt in the data-and-code archive contains the analysis documentation.
